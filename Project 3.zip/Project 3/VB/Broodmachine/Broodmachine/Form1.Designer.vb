﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnBrood1 = New System.Windows.Forms.Button()
        Me.btnBrood2 = New System.Windows.Forms.Button()
        Me.btnBrood3 = New System.Windows.Forms.Button()
        Me.btnBrood4 = New System.Windows.Forms.Button()
        Me.btnBrood9 = New System.Windows.Forms.Button()
        Me.btnBrood8 = New System.Windows.Forms.Button()
        Me.btnBrood7 = New System.Windows.Forms.Button()
        Me.btnBrood6 = New System.Windows.Forms.Button()
        Me.btnBrood5 = New System.Windows.Forms.Button()
        Me.btnBrood10 = New System.Windows.Forms.Button()
        Me.btnBrood15 = New System.Windows.Forms.Button()
        Me.btnBrood14 = New System.Windows.Forms.Button()
        Me.btnBrood13 = New System.Windows.Forms.Button()
        Me.btnBrood11 = New System.Windows.Forms.Button()
        Me.btnBrood12 = New System.Windows.Forms.Button()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.cbType = New System.Windows.Forms.ComboBox()
        Me.numAantal = New System.Windows.Forms.NumericUpDown()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.numPrijs = New System.Windows.Forms.NumericUpDown()
        Me.lblSoort = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtBedrag = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnHelpPersoon = New System.Windows.Forms.Button()
        Me.btnOpslaanPersoon = New System.Windows.Forms.Button()
        Me.lblNaam = New System.Windows.Forms.Label()
        Me.btnHulpBrood = New System.Windows.Forms.Button()
        Me.lblNummer1 = New System.Windows.Forms.Label()
        Me.lblNummer2 = New System.Windows.Forms.Label()
        Me.lblNummer3 = New System.Windows.Forms.Label()
        Me.lblNummer4 = New System.Windows.Forms.Label()
        Me.lblNummer5 = New System.Windows.Forms.Label()
        Me.lblNummer7 = New System.Windows.Forms.Label()
        Me.lblNummer10 = New System.Windows.Forms.Label()
        Me.lblNummer13 = New System.Windows.Forms.Label()
        Me.lblNummer6 = New System.Windows.Forms.Label()
        Me.lblNummer8 = New System.Windows.Forms.Label()
        Me.lblNummer9 = New System.Windows.Forms.Label()
        Me.lblNummer11 = New System.Windows.Forms.Label()
        Me.lblNummer12 = New System.Windows.Forms.Label()
        Me.lblNummer14 = New System.Windows.Forms.Label()
        Me.lblNummer15 = New System.Windows.Forms.Label()
        Me.numLocatie = New System.Windows.Forms.NumericUpDown()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.btnLocatieHulp = New System.Windows.Forms.Button()
        Me.txtKlantcode = New System.Windows.Forms.TextBox()
        Me.lblBedrag = New System.Windows.Forms.Label()
        Me.btnRefresh = New System.Windows.Forms.Button()
        CType(Me.numAantal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numPrijs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numLocatie, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBrood1
        '
        Me.btnBrood1.BackColor = System.Drawing.SystemColors.Control
        Me.btnBrood1.Location = New System.Drawing.Point(69, 56)
        Me.btnBrood1.Name = "btnBrood1"
        Me.btnBrood1.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood1.TabIndex = 0
        Me.btnBrood1.Text = "Button1"
        Me.btnBrood1.UseVisualStyleBackColor = False
        '
        'btnBrood2
        '
        Me.btnBrood2.Location = New System.Drawing.Point(159, 56)
        Me.btnBrood2.Name = "btnBrood2"
        Me.btnBrood2.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood2.TabIndex = 1
        Me.btnBrood2.Text = "BtnBrood2"
        Me.btnBrood2.UseVisualStyleBackColor = True
        '
        'btnBrood3
        '
        Me.btnBrood3.Location = New System.Drawing.Point(258, 56)
        Me.btnBrood3.Name = "btnBrood3"
        Me.btnBrood3.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood3.TabIndex = 2
        Me.btnBrood3.Text = "Button1"
        Me.btnBrood3.UseVisualStyleBackColor = True
        '
        'btnBrood4
        '
        Me.btnBrood4.Location = New System.Drawing.Point(69, 145)
        Me.btnBrood4.Name = "btnBrood4"
        Me.btnBrood4.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood4.TabIndex = 3
        Me.btnBrood4.Text = "Button1"
        Me.btnBrood4.UseVisualStyleBackColor = True
        '
        'btnBrood9
        '
        Me.btnBrood9.Location = New System.Drawing.Point(258, 224)
        Me.btnBrood9.Name = "btnBrood9"
        Me.btnBrood9.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood9.TabIndex = 4
        Me.btnBrood9.Text = "Button1"
        Me.btnBrood9.UseVisualStyleBackColor = True
        '
        'btnBrood8
        '
        Me.btnBrood8.Location = New System.Drawing.Point(159, 224)
        Me.btnBrood8.Name = "btnBrood8"
        Me.btnBrood8.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood8.TabIndex = 5
        Me.btnBrood8.Text = "Button1"
        Me.btnBrood8.UseVisualStyleBackColor = True
        '
        'btnBrood7
        '
        Me.btnBrood7.Location = New System.Drawing.Point(69, 224)
        Me.btnBrood7.Name = "btnBrood7"
        Me.btnBrood7.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood7.TabIndex = 6
        Me.btnBrood7.Text = "Button1"
        Me.btnBrood7.UseVisualStyleBackColor = True
        '
        'btnBrood6
        '
        Me.btnBrood6.Location = New System.Drawing.Point(258, 145)
        Me.btnBrood6.Name = "btnBrood6"
        Me.btnBrood6.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood6.TabIndex = 7
        Me.btnBrood6.Text = "Button1"
        Me.btnBrood6.UseVisualStyleBackColor = True
        '
        'btnBrood5
        '
        Me.btnBrood5.Location = New System.Drawing.Point(159, 145)
        Me.btnBrood5.Name = "btnBrood5"
        Me.btnBrood5.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood5.TabIndex = 8
        Me.btnBrood5.Text = "Button1"
        Me.btnBrood5.UseVisualStyleBackColor = True
        '
        'btnBrood10
        '
        Me.btnBrood10.Location = New System.Drawing.Point(69, 303)
        Me.btnBrood10.Name = "btnBrood10"
        Me.btnBrood10.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood10.TabIndex = 9
        Me.btnBrood10.Text = "Button1"
        Me.btnBrood10.UseVisualStyleBackColor = True
        '
        'btnBrood15
        '
        Me.btnBrood15.Location = New System.Drawing.Point(258, 382)
        Me.btnBrood15.Name = "btnBrood15"
        Me.btnBrood15.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood15.TabIndex = 10
        Me.btnBrood15.Text = "15"
        Me.btnBrood15.UseVisualStyleBackColor = True
        '
        'btnBrood14
        '
        Me.btnBrood14.Location = New System.Drawing.Point(159, 382)
        Me.btnBrood14.Name = "btnBrood14"
        Me.btnBrood14.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood14.TabIndex = 11
        Me.btnBrood14.Text = "14"
        Me.btnBrood14.UseVisualStyleBackColor = True
        '
        'btnBrood13
        '
        Me.btnBrood13.Location = New System.Drawing.Point(69, 382)
        Me.btnBrood13.Name = "btnBrood13"
        Me.btnBrood13.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood13.TabIndex = 12
        Me.btnBrood13.Text = "13"
        Me.btnBrood13.UseVisualStyleBackColor = True
        '
        'btnBrood11
        '
        Me.btnBrood11.Location = New System.Drawing.Point(159, 302)
        Me.btnBrood11.Name = "btnBrood11"
        Me.btnBrood11.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood11.TabIndex = 13
        Me.btnBrood11.Text = "Button1"
        Me.btnBrood11.UseVisualStyleBackColor = True
        '
        'btnBrood12
        '
        Me.btnBrood12.Location = New System.Drawing.Point(258, 303)
        Me.btnBrood12.Name = "btnBrood12"
        Me.btnBrood12.Size = New System.Drawing.Size(84, 73)
        Me.btnBrood12.TabIndex = 14
        Me.btnBrood12.Text = "Button1"
        Me.btnBrood12.UseVisualStyleBackColor = True
        '
        'BtnClear
        '
        Me.BtnClear.Location = New System.Drawing.Point(376, 427)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.Size = New System.Drawing.Size(59, 23)
        Me.BtnClear.TabIndex = 15
        Me.BtnClear.Text = "Leeg"
        Me.BtnClear.UseVisualStyleBackColor = True
        '
        'cbType
        '
        Me.cbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbType.FormattingEnabled = True
        Me.cbType.Location = New System.Drawing.Point(560, 108)
        Me.cbType.Name = "cbType"
        Me.cbType.Size = New System.Drawing.Size(121, 21)
        Me.cbType.TabIndex = 16
        '
        'numAantal
        '
        Me.numAantal.Location = New System.Drawing.Point(560, 136)
        Me.numAantal.Name = "numAantal"
        Me.numAantal.Size = New System.Drawing.Size(120, 20)
        Me.numAantal.TabIndex = 17
        '
        'BtnSave
        '
        Me.BtnSave.Location = New System.Drawing.Point(560, 188)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(92, 23)
        Me.BtnSave.TabIndex = 18
        Me.BtnSave.Text = "Brood Opslaan"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'numPrijs
        '
        Me.numPrijs.Location = New System.Drawing.Point(560, 162)
        Me.numPrijs.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.numPrijs.Name = "numPrijs"
        Me.numPrijs.Size = New System.Drawing.Size(120, 20)
        Me.numPrijs.TabIndex = 19
        '
        'lblSoort
        '
        Me.lblSoort.AutoSize = True
        Me.lblSoort.Location = New System.Drawing.Point(490, 111)
        Me.lblSoort.Name = "lblSoort"
        Me.lblSoort.Size = New System.Drawing.Size(61, 13)
        Me.lblSoort.TabIndex = 20
        Me.lblSoort.Text = "Soort/Type"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(471, 254)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(241, 13)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "------------------------------------------------------------------------------"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(490, 138)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 13)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Aantal"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(490, 164)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Prijs(cent)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(557, 56)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Brood"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(563, 283)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 13)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "Klant"
        '
        'txtBedrag
        '
        Me.txtBedrag.Location = New System.Drawing.Point(566, 330)
        Me.txtBedrag.Name = "txtBedrag"
        Me.txtBedrag.Size = New System.Drawing.Size(100, 20)
        Me.txtBedrag.TabIndex = 27
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(509, 307)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Klant Code"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(509, 333)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 13)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Bedrag"
        '
        'btnHelpPersoon
        '
        Me.btnHelpPersoon.Location = New System.Drawing.Point(672, 330)
        Me.btnHelpPersoon.Name = "btnHelpPersoon"
        Me.btnHelpPersoon.Size = New System.Drawing.Size(19, 20)
        Me.btnHelpPersoon.TabIndex = 30
        Me.btnHelpPersoon.Text = "?"
        Me.btnHelpPersoon.UseVisualStyleBackColor = True
        '
        'btnOpslaanPersoon
        '
        Me.btnOpslaanPersoon.Location = New System.Drawing.Point(560, 407)
        Me.btnOpslaanPersoon.Name = "btnOpslaanPersoon"
        Me.btnOpslaanPersoon.Size = New System.Drawing.Size(75, 23)
        Me.btnOpslaanPersoon.TabIndex = 32
        Me.btnOpslaanPersoon.Text = "Uitvoeren"
        Me.btnOpslaanPersoon.UseVisualStyleBackColor = True
        '
        'lblNaam
        '
        Me.lblNaam.AutoSize = True
        Me.lblNaam.Location = New System.Drawing.Point(560, 366)
        Me.lblNaam.Name = "lblNaam"
        Me.lblNaam.Size = New System.Drawing.Size(53, 13)
        Me.lblNaam.TabIndex = 33
        Me.lblNaam.Text = "Gebruiker"
        '
        'btnHulpBrood
        '
        Me.btnHulpBrood.Location = New System.Drawing.Point(658, 188)
        Me.btnHulpBrood.Name = "btnHulpBrood"
        Me.btnHulpBrood.Size = New System.Drawing.Size(23, 23)
        Me.btnHulpBrood.TabIndex = 34
        Me.btnHulpBrood.Text = "?"
        Me.btnHulpBrood.UseVisualStyleBackColor = True
        '
        'lblNummer1
        '
        Me.lblNummer1.AutoSize = True
        Me.lblNummer1.Location = New System.Drawing.Point(79, 111)
        Me.lblNummer1.Name = "lblNummer1"
        Me.lblNummer1.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer1.TabIndex = 35
        Me.lblNummer1.Text = "1"
        '
        'lblNummer2
        '
        Me.lblNummer2.AutoSize = True
        Me.lblNummer2.Location = New System.Drawing.Point(168, 111)
        Me.lblNummer2.Name = "lblNummer2"
        Me.lblNummer2.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer2.TabIndex = 36
        Me.lblNummer2.Text = "2"
        '
        'lblNummer3
        '
        Me.lblNummer3.AutoSize = True
        Me.lblNummer3.Location = New System.Drawing.Point(270, 111)
        Me.lblNummer3.Name = "lblNummer3"
        Me.lblNummer3.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer3.TabIndex = 37
        Me.lblNummer3.Text = "3"
        '
        'lblNummer4
        '
        Me.lblNummer4.AutoSize = True
        Me.lblNummer4.Location = New System.Drawing.Point(79, 198)
        Me.lblNummer4.Name = "lblNummer4"
        Me.lblNummer4.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer4.TabIndex = 38
        Me.lblNummer4.Text = "4"
        '
        'lblNummer5
        '
        Me.lblNummer5.AutoSize = True
        Me.lblNummer5.Location = New System.Drawing.Point(168, 198)
        Me.lblNummer5.Name = "lblNummer5"
        Me.lblNummer5.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer5.TabIndex = 39
        Me.lblNummer5.Text = "5"
        '
        'lblNummer7
        '
        Me.lblNummer7.AutoSize = True
        Me.lblNummer7.Location = New System.Drawing.Point(79, 275)
        Me.lblNummer7.Name = "lblNummer7"
        Me.lblNummer7.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer7.TabIndex = 40
        Me.lblNummer7.Text = "7"
        '
        'lblNummer10
        '
        Me.lblNummer10.AutoSize = True
        Me.lblNummer10.Location = New System.Drawing.Point(79, 355)
        Me.lblNummer10.Name = "lblNummer10"
        Me.lblNummer10.Size = New System.Drawing.Size(19, 13)
        Me.lblNummer10.TabIndex = 41
        Me.lblNummer10.Text = "10"
        '
        'lblNummer13
        '
        Me.lblNummer13.AutoSize = True
        Me.lblNummer13.Location = New System.Drawing.Point(79, 432)
        Me.lblNummer13.Name = "lblNummer13"
        Me.lblNummer13.Size = New System.Drawing.Size(19, 13)
        Me.lblNummer13.TabIndex = 42
        Me.lblNummer13.Text = "13"
        '
        'lblNummer6
        '
        Me.lblNummer6.AutoSize = True
        Me.lblNummer6.Location = New System.Drawing.Point(270, 198)
        Me.lblNummer6.Name = "lblNummer6"
        Me.lblNummer6.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer6.TabIndex = 43
        Me.lblNummer6.Text = "6"
        '
        'lblNummer8
        '
        Me.lblNummer8.AutoSize = True
        Me.lblNummer8.Location = New System.Drawing.Point(168, 275)
        Me.lblNummer8.Name = "lblNummer8"
        Me.lblNummer8.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer8.TabIndex = 44
        Me.lblNummer8.Text = "8"
        '
        'lblNummer9
        '
        Me.lblNummer9.AutoSize = True
        Me.lblNummer9.Location = New System.Drawing.Point(270, 275)
        Me.lblNummer9.Name = "lblNummer9"
        Me.lblNummer9.Size = New System.Drawing.Size(13, 13)
        Me.lblNummer9.TabIndex = 45
        Me.lblNummer9.Text = "9"
        '
        'lblNummer11
        '
        Me.lblNummer11.AutoSize = True
        Me.lblNummer11.Location = New System.Drawing.Point(168, 355)
        Me.lblNummer11.Name = "lblNummer11"
        Me.lblNummer11.Size = New System.Drawing.Size(19, 13)
        Me.lblNummer11.TabIndex = 46
        Me.lblNummer11.Text = "11"
        '
        'lblNummer12
        '
        Me.lblNummer12.AutoSize = True
        Me.lblNummer12.Location = New System.Drawing.Point(270, 355)
        Me.lblNummer12.Name = "lblNummer12"
        Me.lblNummer12.Size = New System.Drawing.Size(19, 13)
        Me.lblNummer12.TabIndex = 47
        Me.lblNummer12.Text = "12"
        '
        'lblNummer14
        '
        Me.lblNummer14.AutoSize = True
        Me.lblNummer14.Location = New System.Drawing.Point(168, 432)
        Me.lblNummer14.Name = "lblNummer14"
        Me.lblNummer14.Size = New System.Drawing.Size(19, 13)
        Me.lblNummer14.TabIndex = 48
        Me.lblNummer14.Text = "14"
        '
        'lblNummer15
        '
        Me.lblNummer15.AutoSize = True
        Me.lblNummer15.Location = New System.Drawing.Point(270, 432)
        Me.lblNummer15.Name = "lblNummer15"
        Me.lblNummer15.Size = New System.Drawing.Size(19, 13)
        Me.lblNummer15.TabIndex = 49
        Me.lblNummer15.Text = "15"
        '
        'numLocatie
        '
        Me.numLocatie.Location = New System.Drawing.Point(560, 82)
        Me.numLocatie.Name = "numLocatie"
        Me.numLocatie.ReadOnly = True
        Me.numLocatie.Size = New System.Drawing.Size(92, 20)
        Me.numLocatie.TabIndex = 50
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(490, 84)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(42, 13)
        Me.Label23.TabIndex = 51
        Me.Label23.Text = "Locatie"
        '
        'btnLocatieHulp
        '
        Me.btnLocatieHulp.Location = New System.Drawing.Point(657, 79)
        Me.btnLocatieHulp.Name = "btnLocatieHulp"
        Me.btnLocatieHulp.Size = New System.Drawing.Size(23, 23)
        Me.btnLocatieHulp.TabIndex = 52
        Me.btnLocatieHulp.Text = "?"
        Me.btnLocatieHulp.UseVisualStyleBackColor = True
        '
        'txtKlantcode
        '
        Me.txtKlantcode.Location = New System.Drawing.Point(566, 304)
        Me.txtKlantcode.Name = "txtKlantcode"
        Me.txtKlantcode.Size = New System.Drawing.Size(125, 20)
        Me.txtKlantcode.TabIndex = 53
        '
        'lblBedrag
        '
        Me.lblBedrag.AutoSize = True
        Me.lblBedrag.Location = New System.Drawing.Point(563, 388)
        Me.lblBedrag.Name = "lblBedrag"
        Me.lblBedrag.Size = New System.Drawing.Size(74, 13)
        Me.lblBedrag.TabIndex = 54
        Me.lblBedrag.Text = "Huidig Bedrag"
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(376, 398)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(59, 23)
        Me.btnRefresh.TabIndex = 55
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(693, 476)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.lblBedrag)
        Me.Controls.Add(Me.txtKlantcode)
        Me.Controls.Add(Me.btnLocatieHulp)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.numLocatie)
        Me.Controls.Add(Me.lblNummer15)
        Me.Controls.Add(Me.lblNummer14)
        Me.Controls.Add(Me.lblNummer12)
        Me.Controls.Add(Me.lblNummer11)
        Me.Controls.Add(Me.lblNummer9)
        Me.Controls.Add(Me.lblNummer8)
        Me.Controls.Add(Me.lblNummer6)
        Me.Controls.Add(Me.lblNummer13)
        Me.Controls.Add(Me.lblNummer10)
        Me.Controls.Add(Me.lblNummer7)
        Me.Controls.Add(Me.lblNummer5)
        Me.Controls.Add(Me.lblNummer4)
        Me.Controls.Add(Me.lblNummer3)
        Me.Controls.Add(Me.lblNummer2)
        Me.Controls.Add(Me.lblNummer1)
        Me.Controls.Add(Me.btnHulpBrood)
        Me.Controls.Add(Me.lblNaam)
        Me.Controls.Add(Me.btnOpslaanPersoon)
        Me.Controls.Add(Me.btnHelpPersoon)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtBedrag)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblSoort)
        Me.Controls.Add(Me.numPrijs)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.numAantal)
        Me.Controls.Add(Me.cbType)
        Me.Controls.Add(Me.BtnClear)
        Me.Controls.Add(Me.btnBrood12)
        Me.Controls.Add(Me.btnBrood11)
        Me.Controls.Add(Me.btnBrood13)
        Me.Controls.Add(Me.btnBrood14)
        Me.Controls.Add(Me.btnBrood15)
        Me.Controls.Add(Me.btnBrood10)
        Me.Controls.Add(Me.btnBrood5)
        Me.Controls.Add(Me.btnBrood6)
        Me.Controls.Add(Me.btnBrood7)
        Me.Controls.Add(Me.btnBrood8)
        Me.Controls.Add(Me.btnBrood9)
        Me.Controls.Add(Me.btnBrood4)
        Me.Controls.Add(Me.btnBrood3)
        Me.Controls.Add(Me.btnBrood2)
        Me.Controls.Add(Me.btnBrood1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.numAantal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numPrijs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numLocatie, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBrood1 As Button
    Friend WithEvents btnBrood2 As Button
    Friend WithEvents btnBrood3 As Button
    Friend WithEvents btnBrood4 As Button
    Friend WithEvents btnBrood9 As Button
    Friend WithEvents btnBrood8 As Button
    Friend WithEvents btnBrood7 As Button
    Friend WithEvents btnBrood6 As Button
    Friend WithEvents btnBrood5 As Button
    Friend WithEvents btnBrood10 As Button
    Friend WithEvents btnBrood15 As Button
    Friend WithEvents btnBrood14 As Button
    Friend WithEvents btnBrood13 As Button
    Friend WithEvents btnBrood11 As Button
    Friend WithEvents btnBrood12 As Button
    Friend WithEvents BtnClear As Button
    Friend WithEvents cbType As ComboBox
    Friend WithEvents numAantal As NumericUpDown
    Friend WithEvents BtnSave As Button
    Friend WithEvents numPrijs As NumericUpDown
    Friend WithEvents lblSoort As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtBedrag As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btnHelpPersoon As Button
    Friend WithEvents btnOpslaanPersoon As Button
    Friend WithEvents lblNaam As Label
    Friend WithEvents btnHulpBrood As Button
    Friend WithEvents lblNummer1 As Label
    Friend WithEvents lblNummer2 As Label
    Friend WithEvents lblNummer3 As Label
    Friend WithEvents lblNummer4 As Label
    Friend WithEvents lblNummer5 As Label
    Friend WithEvents lblNummer7 As Label
    Friend WithEvents lblNummer10 As Label
    Friend WithEvents lblNummer13 As Label
    Friend WithEvents lblNummer6 As Label
    Friend WithEvents lblNummer8 As Label
    Friend WithEvents lblNummer9 As Label
    Friend WithEvents lblNummer11 As Label
    Friend WithEvents lblNummer12 As Label
    Friend WithEvents lblNummer14 As Label
    Friend WithEvents lblNummer15 As Label
    Friend WithEvents numLocatie As NumericUpDown
    Friend WithEvents Label23 As Label
    Friend WithEvents btnLocatieHulp As Button
    Friend WithEvents txtKlantcode As TextBox
    Friend WithEvents lblBedrag As Label
    Friend WithEvents btnRefresh As Button
End Class
